/*
Author: Jesmin Sultana
Course: SDEV 200
Due date: 15 March 2022
Purpose: The program complete the JavaFX GUI widgets (controls / windows, etc.) for Airline reservation  */

package application;
import javafx.application.Application;
import javafx.scene.layout.GridPane;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.geometry.Pos;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import java.io.*;
import java.util.*;
import java.util.Arrays;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/*Performing airline reservation tasks*/
class AirLineReservation {
   private String name;
   private int phaseType, seatNo;
   private boolean[] seats = new boolean[20];

   public AirLineReservation() {
       Arrays.fill(seats, true);//initializing array with false
   }
  
   //setting name and phaseType
  
   public void setName(String name) {
       this.name = name;
   }

   public void setPhaseType(int phaseType) {
       this.phaseType = phaseType;
   }
  
   //checking first class seats
   public boolean checkFirstClass() {
       for (int i = 0; i < 6; i++) {
           if (seats[i] == false) {
               seats[i] = true;
               seatNo = i + 1;
               phaseType = 1;
               return true;
           }
       }
       return false;
   }
  
   //checking economy class seats
   public boolean checkEconomyClass() {
       for (int i = 6; i < 20; i++) {
           if (seats[i] == false) {
               seats[i] = true;
               seatNo = i + 1;
               phaseType = 2;
               return true;
           }
       }
       return false;
   }
  
   //showing borading passes
   public void boardingPass() {
       System.out.println("*************************");

       System.out.println("Name: " + name);

       String phase = (phaseType == 1) ? "First Class" : "Economy Class";
       System.out.println("Phase Type: " + phase);

       System.out.println("Seat Number: " + seatNo);

       System.out.println("*************************");
   }
}

public class AirlineRes {// driver class
   public static void main(String[] args) {
       AirLineReservation obj = new AirLineReservation();
       //for dialog box
       JTextField name = new JTextField();
       JTextField phaseType = new JTextField();
       Object[] message = { "Name:", name, "Ticket type (First class=1 and economic class=2):", phaseType };
      
       String n;
       int p;
       String first = "First Class is full, Do you want Economy seats?";
       String economy = "Economy Class is full, Do you want First Class seats?";
      
       while (true) {
           int option = JOptionPane.showConfirmDialog(null, message, "Airline Reservation",JOptionPane.OK_CANCEL_OPTION);
           if (option == JOptionPane.OK_OPTION) {
               n = name.getText();
               p = Integer.parseInt(phaseType.getText());

               obj.setName(n);
               obj.setPhaseType(p);

               switch (p) {
               case 1://first class handling
                   if (obj.checkFirstClass()) {
                       obj.boardingPass();
                   } else {
                       if (obj.checkEconomyClass()) {
                           int dialogButton = JOptionPane.YES_NO_OPTION;
                           int dialogResult = JOptionPane.showConfirmDialog(null, first, "Airline Reservation",dialogButton);
                           if (dialogResult == 0) {
                               obj.boardingPass();
                           } else {
                               JOptionPane.showConfirmDialog(null, "Next Flight leaves in 3 hours", "Airline Reservation",JOptionPane.CLOSED_OPTION);
                           }
                       }
                       else {
                           JOptionPane.showConfirmDialog(null, "Next Flight leaves in 3 hours", "Airline Reservation",JOptionPane.CLOSED_OPTION);
                       }
                   }
                   break;
                  
               case 2://economy class handling
                   if(obj.checkEconomyClass()) {
                       obj.boardingPass();
                   }
                   else {
                       if (obj.checkFirstClass()) {
                           int dialogButton = JOptionPane.YES_NO_OPTION;
                           int dialogResult = JOptionPane.showConfirmDialog(null, economy, "Airline Reservation",dialogButton);
                           if (dialogResult == 0) {
                               obj.boardingPass();
                           } else {
                               JOptionPane.showConfirmDialog(null, "Next Flight leaves in 3 hours", "Airline Reservation",JOptionPane.CLOSED_OPTION);
                           }
                       }
                       else {
                           JOptionPane.showConfirmDialog(null, "Next Flight leaves in 3 hours", "Airline Reservation",JOptionPane.CLOSED_OPTION);
                       }
                   }
                   break;
               }
           } else {//exiting the program
               System.out.println("Thank you for using Airline Reservation.");
               System.exit(0);
           }
           //reseting the buffer from textfields
           name.setText("");
           phaseType.setText("");
       }
   }
}